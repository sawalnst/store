
def send_ton(wallet, amount):
    print(f"Kirim {amount} TON ke {wallet}")
