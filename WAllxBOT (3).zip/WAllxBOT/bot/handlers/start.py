
from aiogram import Router, types
router = Router()

@router.message(commands=["start"])
async def start(msg: types.Message):
    await msg.answer("🚀 Selamat datang! Klik menu untuk membeli TON.")
