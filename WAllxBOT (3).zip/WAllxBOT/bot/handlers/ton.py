
from aiogram import Router, types
from bot.orders.manager import create_order
from bot.payments.midtrans import create_invoice

router = Router()

@router.message(lambda m: m.text.lower() == "beli ton")
async def buy_ton(msg: types.Message):
    order = create_order(msg.from_user.id, 1, "EQxxxx")
    invoice = create_invoice(order["order_id"], 50000)
    await msg.answer(f"💰 Silakan bayar via link berikut:\n{invoice}")
