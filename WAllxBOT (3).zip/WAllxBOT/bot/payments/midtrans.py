
import uuid

def create_invoice(order_id, amount):
    return f"https://sandbox.midtrans.com/pay/{order_id}"
