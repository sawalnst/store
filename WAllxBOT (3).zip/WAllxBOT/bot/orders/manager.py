
import json, uuid, os

FILE = "bot/storage/orders.json"

def create_order(user_id, amount, wallet):
    order = {
        "order_id": str(uuid.uuid4()),
        "user_id": user_id,
        "amount": amount,
        "wallet": wallet,
        "status": "PENDING"
    }
    if os.path.exists(FILE):
        data = json.load(open(FILE))
    else:
        data = []
    data.append(order)
    json.dump(data, open(FILE,"w"), indent=2)
    return order
